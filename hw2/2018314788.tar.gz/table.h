#ifndef _TABLE_H
#define _TABLE_H 1

#include "definition.h"

int cmap(char * _str);

#endif /* table.h */