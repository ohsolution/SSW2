#ifndef _ERRHANDLER_H
#define _ERRHANDLER_H 1

void set_default(void);
void err_check(char * _str);         

#endif /* errhandler.h */