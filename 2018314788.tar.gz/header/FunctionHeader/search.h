#ifndef _SEARCH_H
#define _SEARCH_H 1

#include "../definition.h"

void search(query __input);

#endif /* search.h */
